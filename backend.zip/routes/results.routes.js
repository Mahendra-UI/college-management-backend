const express = require('express');
const pool = require('../models/db');
const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Student Results
 *   description: API endpoints for managing student results
 */


/**
 * @swagger
 * /api/addstudentresult:
 *   post:
 *     summary: Add a new student result
 *     tags: [Student Results]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               username:
 *                 type: string
 *               courseId:
 *                 type: integer
 *               semesterId:
 *                 type: integer
 *               subjectId:
 *                 type: integer
 *               studentCredits:
 *                 type: integer
 *               resultStatus:
 *                 type: string
 *                 enum: [Pass, Fail]
 *     responses:
 *       201:
 *         description: Successfully added student result
 *       400:
 *         description: Bad Request - Student result already exists
 *       500:
 *         description: Internal Server Error
 */
router.post('/addstudentresult', async (req, res) => {
    try {
        const { username, courseId, semesterId, subjectId, studentCredits, resultStatus, subjectGrade } = req.body;

        // ✅ Check for missing fields
        if (!username || !courseId || !semesterId || !subjectId || !studentCredits || !resultStatus || !subjectGrade) {
            return res.status(400).json({ success: false, message: "All fields are required" });
        }

        // ✅ Call the function with the new subjectGrade parameter
        const result = await pool.query(
            `SELECT insert_student_result($1, $2, $3, $4, $5, $6, $7) AS response`,
            [username, courseId, semesterId, subjectId, studentCredits, resultStatus, subjectGrade]
        );

        const responseMessage = result.rows[0].response;

        // ✅ Handle duplicate entry properly
        if (responseMessage === 'Student result already exists') {
            return res.status(400).json({ success: false, message: responseMessage });
        }

        return res.status(201).json({ success: true, message: responseMessage });

    } catch (error) {
        if (error.code === '23505') {  // Catch the duplicate entry error
            return res.status(400).json({ success: false, message: "Student result already exists" });
        }
        console.error("❌ Error adding student result:", error);
        return res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
});




/**
 * @swagger
 * /api/updatestudentresult:
 *   put:
 *     summary: Update a student result
 *     tags: [Student Results]
 */
router.put('/updatestudentresult', async (req, res) => {
    try {
        const { username, courseId, semesterId, subjectId, studentCredits, resultStatus, subjectGrade } = req.body;

        // ✅ Check for missing fields
        if (!username || !courseId || !semesterId || !subjectId || !studentCredits || !resultStatus || !subjectGrade) {
            return res.status(400).json({ success: false, message: "All fields are required" });
        }

        // ✅ Call the updated function with `subjectGrade`
        const result = await pool.query(
            `SELECT update_student_result($1, $2, $3, $4, $5, $6, $7) AS response`,
            [username, courseId, semesterId, subjectId, studentCredits, resultStatus, subjectGrade]
        );

        res.status(200).json({ success: true, message: result.rows[0].response });
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
});



/**
 * @swagger
 * /api/getstudentresult/{result_id}:
 *   get:
 *     summary: Get student result by result_id
 *     tags: [Student Results]
 *     parameters:
 *       - in: path
 *         name: result_id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Successfully fetched student result
 *       400:
 *         description: Invalid request, missing result_id
 *       404:
 *         description: Student result not found
 *       500:
 *         description: Internal server error
 */

router.get('/getstudentresult/:result_id', async (req, res) => {
    try {
        const { result_id } = req.params;

        if (!result_id) {
            return res.status(400).json({ success: false, message: "result_id parameter is required" });
        }

        const result = await pool.query(`SELECT * FROM get_student_result_by_id($1)`, [result_id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Student result not found" });
        }

        res.status(200).json({ success: true, result: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
});



/**
 * @swagger
 * /api/getstudentresults:
 *   get:
 *     summary: Fetch all student results sorted by ascending result_id.
 *     tags: [Student Results]
 */
router.get('/getstudentresults', async (req, res) => {
    try {
        const result = await pool.query(`SELECT * FROM get_all_student_results()`);

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "No results found." });
        }

        res.status(200).json({ success: true, results: result.rows });

    } catch (error) {
        console.error("❌ Error fetching student results:", error);
        res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
});



/**
 * @swagger
 * /api/getstudentresult/{result_id}:
 *   get:
 *     summary: Get student result by result_id
 *     tags: [Student Results]
 */
router.get('/getstudentresult/:result_id', async (req, res) => {
    try {
        const { result_id } = req.params;

        if (!result_id) {
            return res.status(400).json({ success: false, message: "result_id parameter is required" });
        }

        const result = await pool.query(`SELECT * FROM get_student_result_by_id($1)`, [result_id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Student result not found" });
        }

        res.status(200).json({ success: true, result: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
});



/**
 * @swagger
 * /api/getStudentResults/{username}/{semesterId}:
 *   get:
 *     summary: Get student results by username and semester
 *     tags: [Student Results]
 *     parameters:
 *       - in: path
 *         name: username
 *         required: true
 *         schema:
 *           type: string
 *         description: The student's username.
 *       - in: path
 *         name: semesterId
 *         required: true
 *         schema:
 *           type: integer
 *         description: The semester ID.
 *     responses:
 *       200:
 *         description: Successfully retrieved results.
 *       404:
 *         description: No results found for the specified username and semester.
 *       500:
 *         description: Internal Server Error.
 */


router.get('/getStudentResults/:username/:semesterId', async (req, res) => {
    try {
        const { username, semesterId } = req.params;

        // ✅ Validate Input
        if (!username || isNaN(semesterId)) {
            return res.status(400).json({ success: false, message: "Invalid username or semesterId" });
        }

        console.log(`🔍 Fetching results for Username: ${username}, Semester: ${semesterId}`);

        // ✅ Query Student Results
        const results = await pool.query(
            `SELECT * FROM get_student_results_by_username_semester($1, $2)`, 
            [username.trim(), parseInt(semesterId)]
        );

        // ✅ If no results, return an empty list instead of 404
        if (results.rows.length === 0) {
            console.warn("⚠ No results found for this semester.");
            return res.status(200).json({ success: true, results: [] });  // ✅ Return empty list
        }

        console.log("✅ Results Found:", results.rows);
        res.status(200).json({ success: true, results: results.rows });

    } catch (error) {
        console.error("❌ Error fetching student results:", error);
        res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
});




/**
 * @swagger
 * /api/deletestudentresult/{result_id}:
 *   delete:
 *     summary: Delete a student result by result_id
 *     tags: [Student Results]
 *     parameters:
 *       - in: path
 *         name: result_id
 *         required: true
 *         schema:
 *           type: integer
 *         description: The unique result ID of the student result to be deleted.
 *     responses:
 *       200:
 *         description: Successfully deleted student result
 *       404:
 *         description: Student result not found
 *       500:
 *         description: Internal Server Error
 */


router.delete('/deletestudentresult/:result_id', async (req, res) => {
    try {
        const { result_id } = req.params;

        if (!result_id || isNaN(result_id)) {
            return res.status(400).json({ success: false, message: "Invalid result_id parameter" });
        }

        console.log(`🔍 Deleting student result with ID: ${result_id}`);

        const result = await pool.query(`SELECT delete_student_result_by_id($1) AS response`, [result_id]);

        if (result.rows[0].response === 'Student result not found') {
            console.warn("⚠ Student result not found.");
            return res.status(404).json({ success: false, message: "Student result not found" });
        }

        console.log("✅ Student result deleted successfully.");
        res.status(200).json({ success: true, message: result.rows[0].response });

    } catch (error) {
        console.error("❌ Error deleting student result:", error);
        res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
});


/**
 * @swagger
 * /api/getstudentresultsbyusername/{username}:
 *   get:
 *     summary: Get student results by username
 *     tags: [Student Results]
 *     description: Fetches student result data based on the username using the stored function.
 *     parameters:
 *       - in: path
 *         name: username
 *         required: true
 *         schema:
 *           type: string
 *         description: The username of the student whose results are to be fetched.
 *     responses:
 *       200:
 *         description: Successfully fetched student results.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 results:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       result_id:
 *                         type: integer
 *                       username:
 *                         type: string
 *                       full_name:
 *                         type: string
 *                       course_name:
 *                         type: string
 *                       semester_name:
 *                         type: string
 *                       subject_name:
 *                         type: string
 *                       subject_code:
 *                         type: string
 *                       total_credits:
 *                         type: integer
 *                       earned_credits:
 *                         type: integer
 *                       result_status:
 *                         type: string
 *                       created_at:
 *                         type: string
 *                         format: date-time
 *                       updated_at:
 *                         type: string
 *                         format: date-time
 *       400:
 *         description: Invalid request, missing username
 *       404:
 *         description: Student results not found
 *       500:
 *         description: Internal server error
 */
router.get('/getstudentresultsbyusername/:username', async (req, res) => {
    try {
        const { username } = req.params;

        if (!username) {
            return res.status(400).json({ success: false, message: "Username parameter is required" });
        }

        console.log(`🔍 Fetching student results for username: ${username}`);

        // Call the PostgreSQL function
        const result = await pool.query(`SELECT * FROM get_student_results_by_username($1)`, [username]);

        if (result.rows.length === 0) {
            console.warn("⚠ No student results found.");
            return res.status(404).json({ success: false, message: "Student results not found" });
        }

        console.log("✅ Student results found:", result.rows);
        res.status(200).json({ success: true, results: result.rows });

    } catch (error) {
        console.error("❌ Error fetching student results:", error);
        res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
});



/**
 * @swagger
 * /api/updatestudentcgpa:
 *   put:
 *     summary: Update student's CGPA
 *     tags: [Student Results]
 *     description: Updates the CGPA of a student using their username.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               username:
 *                 type: string
 *               cgpa:
 *                 type: number
 *                 format: float
 *                 example: 8.75
 *     responses:
 *       200:
 *         description: Successfully updated CGPA.
 *       400:
 *         description: Bad request (missing username or CGPA).
 *       500:
 *         description: Internal Server Error.
 */
router.put('/updatestudentcgpa', async (req, res) => {
    try {
        const { username, cgpa } = req.body;

        if (!username || cgpa === undefined) {
            return res.status(400).json({ success: false, message: "Username and CGPA are required" });
        }

        const result = await pool.query(
            "UPDATE students SET cgpa = $1, updated_at = NOW() WHERE username = $2 RETURNING *",
            [cgpa, username]
        );

        if (result.rowCount === 0) {
            return res.status(404).json({ success: false, message: "Student not found" });
        }

        res.status(200).json({ success: true, message: "CGPA updated successfully", student: result.rows[0] });

    } catch (error) {
        console.error("❌ Error updating CGPA:", error);
        res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
});


/**
 * @swagger
 * /api/updatestudentcgpa:
 *   put:
 *     tags: [Student Results]
 *     summary: Update CGPA for a student
 *     description: Updates the CGPA of a student identified by their username.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               username:
 *                 type: string
 *               cgpa:
 *                 type: number
 *                 format: float
 *                 example: 8.75
 *     responses:
 *       '200':
 *         description: Successfully updated CGPA.
 *       '400':
 *         description: Missing username or CGPA.
 *       '500':
 *         description: Internal Server Error.
 */
router.put('/updatestudentcgpa', async (req, res) => {
    try {
        const { username, cgpa } = req.body;

        if (!username || cgpa === undefined) {
            return res.status(400).json({ success: false, message: "Username and CGPA are required" });
        }

        // ✅ Update CGPA in Database
        const result = await pool.query('UPDATE students SET cgpa = $1, updated_at = NOW() WHERE username = $2 RETURNING *', [cgpa, username]);

        if (result.rowCount === 0) {
            return res.status(404).json({ success: false, message: "Student not found" });
        }

        res.status(200).json({ success: true, message: "CGPA updated successfully", student: result.rows[0] });
    } catch (error) {
        console.error('❌ Error updating CGPA:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error', error: error.message });
    }
});




/**
 * @swagger
 * /api/getcgpa/{username}:
 *   get:
 *     summary: Fetch CGPA of a student
 *     tags: [Student Results]
 *     description: Retrieve the CGPA of a student using their username.
 *     parameters:
 *       - name: username
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *         description: "The student's username."
 *     responses:
 *       200:
 *         description: Successfully retrieved CGPA.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 cgpa:
 *                   type: number
 *                   format: float
 *                   example: 8.75
 *       400:
 *         description: Invalid username provided.
 *       404:
 *         description: CGPA not found for the given username.
 *       500:
 *         description: Internal Server Error.
 */
router.get('/getcgpa/:username', async (req, res) => {
    try {
        const { username } = req.params;

        if (!username) {
            return res.status(400).json({ success: false, message: "Invalid username" });
        }

        const result = await pool.query("SELECT get_student_cgpa($1)", [username]);

        if (result.rows.length === 0 || result.rows[0].get_student_cgpa === null) {
            return res.status(404).json({ success: false, message: "CGPA not found for this student" });
        }

        res.status(200).json({ success: true, cgpa: result.rows[0].get_student_cgpa });

    } catch (error) {
        console.error("❌ Error fetching CGPA:", error);
        res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
});


/**
 * @swagger
 * /api/getallcgpa:
 *   get:
 *     summary: Fetch CGPA of all students
 *     tags: [Student CGPA]
 *     responses:
 *       200:
 *         description: Successfully retrieved all students' CGPA.
 */
router.get('/getallcgpa', async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM get_all_students_cgpa()");

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "No CGPA records found." });
        }

        res.status(200).json({ success: true, students: result.rows });
    } catch (error) {
        console.error("❌ Error fetching CGPA records:", error);
        res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
});



/**
 * @swagger
 * /api/getallsgpacgpa:
 *   get:
 *     summary: Fetch SGPA and CGPA of all students
 *     tags: [Student SGPA & CGPA]
 *     responses:
 *       200:
 *         description: Successfully retrieved all students' SGPA and CGPA.
 */
router.get('/getallsgpacgpa', async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM get_all_students_sgpa_cgpa()");

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "No SGPA/CGPA records found." });
        }

        res.status(200).json({ success: true, students: result.rows });
    } catch (error) {
        console.error("❌ Error fetching SGPA/CGPA records:", error);
        res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
});


/**
 * @swagger
 * /api/update-sgpa:
 *   put:
 *     summary: Update SGPA for a student
 *     tags: [Student SGPA]
 *     parameters:
 *       - in: body
 *         name: sgpaUpdate
 *         description: Update a student's semester SGPA values
 *         required: true
 *         schema:
 *           type: object
 *           properties:
 *             student_id:
 *               type: integer
 *             first_semester_sgpa:
 *               type: number
 *             second_semester_sgpa:
 *               type: number
 *             third_semester_sgpa:
 *               type: number
 *             fourth_semester_sgpa:
 *               type: number
 *     responses:
 *       200:
 *         description: Successfully updated the student's SGPA.
 *       400:
 *         description: Invalid input data.
 *       500:
 *         description: Internal server error.
 */
router.put('/update-sgpa-cgpa', async (req, res) => {
    try {
        const {
            student_id,
            first_semester_sgpa,
            second_semester_sgpa,
            third_semester_sgpa,
            fourth_semester_sgpa,
            cgpa  // ✅ Added CGPA
        } = req.body;

        if (!student_id) {
            return res.status(400).json({ success: false, message: "Student ID is required." });
        }

        const query = `
            SELECT update_student_sgpa_cgpa($1, $2, $3, $4, $5, $6)
        `;

        await pool.query(query, [
            student_id,
            first_semester_sgpa || null,  // ✅ Ensure NULL values are passed correctly
            second_semester_sgpa || null,
            third_semester_sgpa || null,
            fourth_semester_sgpa || null,
            cgpa || null  // ✅ Now supports CGPA updates
        ]);

        res.status(200).json({ success: true, message: "SGPA & CGPA updated successfully." });
    } catch (error) {
        console.error("❌ Error updating SGPA & CGPA:", error);
        res.status(500).json({ success: false, message: "Internal Server Error", error: error.message });
    }
});



module.exports = router;
